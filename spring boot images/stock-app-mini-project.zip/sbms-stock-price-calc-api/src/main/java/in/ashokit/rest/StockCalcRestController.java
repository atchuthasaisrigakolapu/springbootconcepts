package in.ashokit.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import in.ashokit.binding.StockPrice;
import in.ashokit.client.StockPriceClient;

@RestController
public class StockCalcRestController {

	@Autowired
	private StockPriceClient priceClient;

	@GetMapping("/calc/{cname}/{qty}")
	public ResponseEntity<String> calculate(@PathVariable String cname, @PathVariable Integer qty) {

		StockPrice stockPrice = priceClient.invokeStockPrice(cname);
		
		Double companyPrice = stockPrice.getCompanyPrice();
		String portNumber = stockPrice.getPortNumber();

		Double totalCost = companyPrice * qty;

		String msg = "Total Cost : " + totalCost + " ( Price api SERVER PORT :: " + portNumber + " )";

		return new ResponseEntity<>(msg, HttpStatus.OK);
	}
}