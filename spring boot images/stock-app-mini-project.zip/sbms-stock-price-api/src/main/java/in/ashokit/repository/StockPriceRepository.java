package in.ashokit.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ashokit.entity.StockPrice;

public interface StockPriceRepository extends JpaRepository<StockPrice, Integer> {

	public StockPrice findByCompanyName(String companyName);
}